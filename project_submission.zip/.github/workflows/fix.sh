#!/bin/bash
cd /workspace

echo "Creating clean project_submission.zip using Python..."

python3 -c "
import zipfile, os

exclude_dirs = {'node_modules', '.git', '__pycache__', '.terraform'}
targets = ['.github', 'setup', 'starter', 'README.md', 'screenshots']

with zipfile.ZipFile('project_submission.zip', 'w', zipfile.ZIP_DEFLATED) as zipf:
    for target in targets:
        if os.path.isfile(target):
            zipf.write(target, arcname=target)
        elif os.path.isdir(target):
            for root, dirs, files in os.walk(target):
                dirs[:] = [d for d in dirs if d not in exclude_dirs]
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, '.')
                    zipf.write(file_path, arcname)

print('ZIP file packaging completed successfully!')
"

echo "=========================================="
ls -lh project_submission.zip
echo "=========================================="